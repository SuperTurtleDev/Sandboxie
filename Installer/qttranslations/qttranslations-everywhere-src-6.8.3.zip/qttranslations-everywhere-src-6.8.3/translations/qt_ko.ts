<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko">
<dependencies>
<dependency catalog="qtbase_ko"/>
<dependency catalog="qtmultimedia_ko"/>
</dependencies>
</TS>
